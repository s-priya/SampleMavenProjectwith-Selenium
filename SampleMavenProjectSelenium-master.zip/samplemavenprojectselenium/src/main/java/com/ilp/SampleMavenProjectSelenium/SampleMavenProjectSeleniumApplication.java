package com.ilp.SampleMavenProjectSelenium;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampleMavenProjectSeleniumApplication {

	public static void main(String[] args) {
		SpringApplication.run(SampleMavenProjectSeleniumApplication.class, args);
	}

}
