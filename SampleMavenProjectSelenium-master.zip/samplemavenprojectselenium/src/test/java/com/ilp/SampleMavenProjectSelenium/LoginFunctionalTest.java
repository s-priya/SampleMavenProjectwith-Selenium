package com.ilp.SampleMavenProjectSelenium;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.event.annotation.AfterTestClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.*;


public class LoginFunctionalTest {

static FirefoxDriver driver; 

String baseURL="http://localhost:5050/SampleMavenProject"; 
@BeforeAll
	public static void setup() { 
	
		FirefoxBinary firefoxBinary = new FirefoxBinary(); 
	
	    firefoxBinary.addCommandLineOptions("--headless"); 
	
	    System.setProperty("webdriver.gecko.driver", "/usr/bin/geckodriver"); 
	
	    FirefoxOptions firefoxOptions = new FirefoxOptions(); 
	
	    firefoxOptions.setBinary(firefoxBinary); 
	
	     
	
	    driver = new FirefoxDriver(firefoxOptions);
	}
	@AfterTestClass
	public static void cleanup() {
		driver.quit();
	}
	
	@Test
	public void testHomePage() {
		driver.get(baseURL+"/");
		String title= driver.getTitle();
		assertEquals("Welcome", title);
		assertTrue(driver.getPageSource().contains("Welcome to Sample Maven Project!!!"));
	}
	
	@Test
	public void testLoginPage() {
		driver.get(baseURL+"/login");
		 WebElement username = driver.findElement(By.name("username")); 

	        WebElement pass = driver.findElement(By.name("password")); 

	        WebElement submitLogin = driver.findElement(By.name("login"));          

	        username.sendKeys("priya"); 

	        pass.sendKeys("wipro@123"); 

	        submitLogin.click(); 

	        assertTrue(driver.getPageSource().contains("Hello World!"));
	}
	
	@Test
	public void testRegisterPage() {
		driver.get(baseURL+"/register");
		WebElement username = driver.findElement(By.name("username")); 

	        WebElement pass = driver.findElement(By.name("password")); 

	        WebElement submitLogin = driver.findElement(By.id("register"));          

	        username.sendKeys("test"); 

	        pass.sendKeys("wipro@123"); 

	        submitLogin.click(); 

	        assertTrue(driver.getPageSource().contains("Hello World!"));
	}

}

