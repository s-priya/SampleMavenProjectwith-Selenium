DROP TABLE IF EXISTS users;
CREATE TABLE users(
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(250) NOT NULL,
    password VARCHAR(250) NOT NULL,
    firstname VARCHAR(250) NOT NULL,
    lastname VARCHAR(250),
    email VARCHAR(250) NOT NULL,
    address VARCHAR(250) NOT NULL,
    phone VARCHAR(250)
);

insert into users (username,password,firstname,lastname,email,address,phone) values('priya', 'wipro@123', 'priya','','priya@gmail.com','chennai','9876543210');
insert into users (username,password,firstname,lastname,email,address,phone) values('sam', 'wipro@123', 'sam','','sam@gmail.com','chennai','9876543210');