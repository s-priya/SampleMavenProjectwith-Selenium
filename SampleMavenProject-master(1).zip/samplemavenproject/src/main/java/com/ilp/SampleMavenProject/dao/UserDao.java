package com.ilp.SampleMavenProject.dao;

import com.ilp.SampleMavenProject.model.Login;
import com.ilp.SampleMavenProject.model.User;

public interface UserDao {

  int register(User user);

  User validateUser(Login login);
}
