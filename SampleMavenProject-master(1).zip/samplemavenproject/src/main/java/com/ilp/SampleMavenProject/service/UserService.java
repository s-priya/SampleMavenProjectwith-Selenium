package com.ilp.SampleMavenProject.service;
import com.ilp.SampleMavenProject.model.*;

public interface UserService {

	  int register(User user);

	  User validateUser(Login login);
	  
	  String getFullname(User user) ;
	}
