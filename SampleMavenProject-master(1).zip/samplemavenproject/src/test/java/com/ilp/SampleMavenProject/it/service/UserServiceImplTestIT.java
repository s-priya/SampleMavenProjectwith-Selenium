package com.ilp.SampleMavenProject.it.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

import com.ilp.SampleMavenProject.model.Login;
import com.ilp.SampleMavenProject.model.User;
import com.ilp.SampleMavenProject.service.UserService;
import com.ilp.SampleMavenProject.service.UserServiceImpl;
@SpringBootTest
@TestPropertySource(locations="classpath:application-test.properties")
@TestMethodOrder(MethodOrderer.Alphanumeric.class)
class UserServiceImplTestIT {
	private static User p1;
	private static User p2;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		p1 = new User("priya", "wipro@123", "priya","","priya@gmail.com","chennai","9876543210");
		p2 = new User("sam", "wipro@123", "sam","","sam@gmail.com","chennai","9876543210");
	}

	@Autowired
	private UserService userService = new UserServiceImpl();
	

	@Test
	void testRegister() {
		int value=userService.register(p1);
		assertEquals(1, value);
	}
	@Test
	void testValidateUser() {
		Login login=new Login("sam", "wipro@123");
		User loggedinUser= userService.validateUser(login);
		assertEquals(p2.getUsername(), loggedinUser.getUsername());
	}
@Test
void testGetFullName() {
	String fullName=userService.getFullname(p2);
	assertEquals(p2.getFirstname()+" "+p2.getLastname(), fullName);
}

}
