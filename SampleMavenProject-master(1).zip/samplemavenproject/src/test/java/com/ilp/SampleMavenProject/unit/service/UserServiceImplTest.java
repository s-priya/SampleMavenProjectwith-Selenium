package com.ilp.SampleMavenProject.unit.service;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;

import com.ilp.SampleMavenProject.dao.UserDao;
import com.ilp.SampleMavenProject.model.Login;
import com.ilp.SampleMavenProject.model.User;
import com.ilp.SampleMavenProject.service.UserService;
import com.ilp.SampleMavenProject.service.UserServiceImpl;

@TestMethodOrder(MethodOrderer.Alphanumeric.class)
@SpringBootTest
@ExtendWith(MockitoExtension.class)
public class UserServiceImplTest {

	private static User p1;
	private static User p2;
	
	 @Mock
	    private UserDao userDao;
@InjectMocks
	    private UserService userService = new UserServiceImpl();
@BeforeAll
public static void init() {
	p1 = new User("priya", "wipro@123", "priya","","priya@gmail.com","chennai","9876543210");
	p2 = new User("sam", "wipro@123", "sam","","sam@gmail.com","chennai","9876543210");
}

	@Test
	void testRegister() {
		Mockito.when(userDao.register(p1)).thenReturn(1);
		assertEquals(1,userService.register(p1));
	}

	@Test
	void testValidateUser() {
		Login login=new Login("sam", "wipro@123");
		Mockito.when(userDao.validateUser(login)).thenReturn(p2);
		User loggedinUser= userService.validateUser(login);
		assertEquals(p2.getUsername(), loggedinUser.getUsername());
	}
@Test
void testGetFullName() {
	String fullName=userService.getFullname(p2);
	assertEquals(p2.getFirstname()+" "+p2.getLastname(), fullName);
}
}
